/* ordering.js — reproduces the operand ordering figures in Section 7.
 * Fully deterministic. Run with:  node ordering.js
 */
"use strict";

const CHAIN = [[0,0],[0,0],[1,1],[1,2],[2,2],[1,4],[3,3],[1,6],[4,4],[3,6]];

function toDigits(n){
  const s = String(n), d = [];
  for (let i = s.length - 1; i >= 0; i--) d.push(s.charCodeAt(i) - 48);
  return d;
}

/* Decimal add with the "+6 and mask" correction, so no subtraction is used. */
function addAt(acc, src, off, st){
  let i = 0, s, carry = 0;
  for (i = 0; i < src.length && off + i < acc.length; i++){
    s = acc[off + i] + src[i] + carry;
    st.adds++;
    carry = s > 9 ? 1 : 0;
    acc[off + i] = carry ? ((s + 6) & 0x0F) : s;
  }
  while (carry && off + i < acc.length){
    s = acc[off + i] + 1;
    st.adds++;
    carry = s > 9 ? 1 : 0;
    acc[off + i] = carry ? ((s + 6) & 0x0F) : s;
    i++;
  }
}

function markNeeded(y){
  const need = new Array(10).fill(0);
  for (const d of y) if (d > 1) need[d] = 1;
  for (let k = 9; k >= 2; k--)
    if (need[k]){ need[CHAIN[k][0]] = 1; need[CHAIN[k][1]] = 1; }
  need[0] = need[1] = 0;
  return need;
}

/* Full run. Returns the product and the number of digit additions used. */
function run(a, b){
  const x = toDigits(a), y = toDigits(b), tn = x.length + 1, t = [];
  for (let k = 0; k < 10; k++) t.push(new Array(tn).fill(0));
  for (let i = 0; i < x.length; i++) t[1][i] = x[i];

  const need = markNeeded(y), st = { adds: 0 };
  for (let k = 2; k <= 9; k++){
    if (!need[k]) continue;
    for (let i = 0; i < tn; i++) t[k][i] = t[CHAIN[k][0]][i];
    addAt(t[k], t[CHAIN[k][1]], 0, st);
  }

  const acc = new Array(x.length + y.length).fill(0);
  for (let j = 0; j < y.length; j++){
    if (y[j] === 0) continue;
    addAt(acc, t[y[j]], j, st);           /* j is the shift */
  }

  let p = "";
  for (let i = acc.length - 1; i >= 0; i--) p += acc[i];
  return { product: p.replace(/^0+(?=\d)/, ""), adds: st.adds };
}

/* Predictor: (T(y) + z(y)) * (len(x) + 1). No full multiplication needed. */
function orderCost(xLen, b){
  const y = toDigits(b), need = markNeeded(y);
  let T = 0, z = 0;
  for (let k = 2; k <= 9; k++) T += need[k];
  for (const d of y) if (d !== 0) z++;
  return (T + z) * (xLen + 1);
}

console.log("Section 7 — operand ordering\n");
console.log("  pair                      as given   reversed");
for (const [a, b] of [[726,25],[305,407],[99999,99999],[123456,987654],
                      [1234,5678],[10,999999999]]){
  const f = run(a, b), r = run(b, a);
  if (f.product !== String(a * b) || r.product !== String(a * b))
    throw new Error("wrong product for " + a + " x " + b);
  console.log("  " + (a + " x " + b).padEnd(26) +
              String(f.adds).padStart(6) + String(r.adds).padStart(11) +
              (r.adds < f.adds ? "   reversed is cheaper" : ""));
}

let better = 0, worse = 0, tie = 0, total = 0, saved = 0, largest = 0, largestAt = null;
let base = 0, best = 0, decided = 0, mispredicted = 0;

for (let a = 2; a < 3000; a += 7)
  for (let b = 2; b < 3000; b += 11){
    const f = run(a, b).adds, r = run(b, a).adds;
    total++;
    base += f;
    best += Math.min(f, r);
    if (r < f){
      better++; saved += f - r;
      if (f - r > largest){ largest = f - r; largestAt = [a, b]; }
    } else if (r > f) worse++;
    else tie++;

    if (f !== r){
      decided++;
      const predictReverse = orderCost(String(b).length, a) < orderCost(String(a).length, b);
      if (predictReverse !== (r < f)) mispredicted++;
    }
  }

const pc = n => (100 * n / total).toFixed(1) + "%";
console.log("\n  sweep of " + total.toLocaleString("en-US") + " pairs");
console.log("    reversing is cheaper       : " + better.toLocaleString("en-US") + "  (" + pc(better) + ")");
console.log("    reversing is worse         : " + worse.toLocaleString("en-US") + "  (" + pc(worse) + ")");
console.log("    no difference              : " + tie.toLocaleString("en-US") + "  (" + pc(tie) + ")");
console.log("    mean saving when it helps  : " + (saved / better).toFixed(1) + " additions");
console.log("    largest single saving      : " + largest + " on " + largestAt[0] + " x " + largestAt[1]);
console.log("\n  predictor correct on " + (decided - mispredicted).toLocaleString("en-US") +
            " / " + decided.toLocaleString("en-US") + " decided pairs");
console.log("  total additions, as given : " + base.toLocaleString("en-US"));
console.log("  total additions, best     : " + best.toLocaleString("en-US") +
            "   (" + (100 * (base - best) / base).toFixed(1) + "% saved)");

/* Correctness sweep. */
let bad = 0;
for (let a = 0; a < 400; a++)
  for (let b = 0; b < 400; b++)
    if (run(a, b).product !== String(a * b)) bad++;
console.log("\n  correctness sweep 0..399 x 0..399 : " + (bad ? bad + " FAILURES" : "all 160,000 products correct"));
