/* decmul.c — decimal multiplication on an add-only, decimal-word CPU.
 *
 * Machine model
 *   - Every number is an array of decimal digits, one digit per addressable
 *     cell, index 0 = least significant.
 *   - The ALU offers digit addition with decimal carry correction. No
 *     subtraction, no multiply, no shifter.
 *   - Memory offers load/store with an immediate index offset.
 *
 * Consequence: multiplying by 10^j is not an operation. It is the index the
 * partial product is written at.
 */

#include <stdint.h>
#include <string.h>
#include <stdio.h>

#define MAXD 64

uint64_t g_digit_adds = 0;   /* instrumentation only */

/* acc[off..] += src[0..slen-1]
 * Decimal correction uses "+6 then mask" so no subtraction is ever needed:
 * for s in 10..19, (s+6) & 0x0F == s-10, and the carry falls out of the nibble.
 */
static void add_at(uint8_t *acc, int alen,
                   const uint8_t *src, int slen, int off)
{
    int i, s, carry = 0;

    for (i = 0; i < slen && off + i < alen; i++) {
        s = acc[off + i] + src[i] + carry;
        g_digit_adds++;
        carry = (s > 9);
        acc[off + i] = (uint8_t)(carry ? ((s + 6) & 0x0F) : s);
    }
    while (carry && off + i < alen) {
        s = acc[off + i] + 1;
        g_digit_adds++;
        carry = (s > 9);
        acc[off + i] = (uint8_t)(carry ? ((s + 6) & 0x0F) : s);
        i++;
    }
}

/* Addition chain over the digit multiples.
 * CHAIN[k] = {a, b} means  k*x = a*x + b*x,  with a,b < k so the table can be
 * filled in ascending order. One addition per entry; nine additions total.
 */
static const uint8_t CHAIN[10][2] = {
    {0, 0},   /* 0  all zero, no work            */
    {0, 0},   /* 1  copy of the multiplicand     */
    {1, 1},   /* 2 = 1 + 1                       */
    {1, 2},   /* 3 = 1 + 2                       */
    {2, 2},   /* 4 = 2 + 2                       */
    {1, 4},   /* 5 = 1 + 4                       */
    {3, 3},   /* 6 = 3 + 3                       */
    {1, 6},   /* 7 = 1 + 6   <- the entry the original notes omitted */
    {4, 4},   /* 8 = 4 + 4                       */
    {3, 6}    /* 9 = 3 + 6                       */
};

/* Mark which chain entries are actually reachable from the digits of y, so a
 * multiplier like 25 builds only 2, 4, 5 rather than the whole table.
 */
static void mark_needed(const uint8_t *y, int yn, int need[10])
{
    int k, d;

    memset(need, 0, 10 * sizeof(int));
    for (d = 0; d < yn; d++)
        if (y[d] > 1) need[y[d]] = 1;

    for (k = 9; k >= 2; k--)
        if (need[k]) {
            need[CHAIN[k][0]] = 1;
            need[CHAIN[k][1]] = 1;
        }
    need[0] = 0;
    need[1] = 0;
}

/* ---- operand ordering ------------------------------------------------
 *
 * a*b == b*a, so either operand may play multiplicand. The two orderings do
 * not cost the same: the table cost scales with the multiplicand's LENGTH,
 * the accumulation cost with the multiplier's DIGIT CONTENT.
 *
 *      cost(x as multiplicand, y as multiplier) ~ (T(y) + z(y)) * (xn + 1)
 *
 *          T(y) = chain entries needed to reach the digits of y
 *          z(y) = count of nonzero digits of y
 *
 * Evaluating this needs no multiplication of full operands: both factors are
 * below 20, so the product is itself a table entry on this machine.
 */
static int order_cost(int xn, const uint8_t *y, int yn)
{
    int need[10], k, j, T = 0, z = 0;

    mark_needed(y, yn, need);
    for (k = 2; k <= 9; k++) T += need[k];
    for (j = 0; j < yn; j++) if (y[j] != 0) z++;

    return (T + z) * (xn + 1);
}

/* Returns 1 if the operands should be swapped before multiplying. */
int prefer_swap(const uint8_t *x, int xn, const uint8_t *y, int yn)
{
    return order_cost(yn, x, xn) < order_cost(xn, y, yn);
}

/* out must have room for xn + yn digits. */
void dec_mul(const uint8_t *x, int xn,
             const uint8_t *y, int yn,
             uint8_t *out, int lazy)
{
    uint8_t t[10][MAXD];
    int need[10];
    int tn = xn + 1;            /* 9*x needs at most one extra digit */
    int k, j;

    memset(t, 0, sizeof t);
    memcpy(t[1], x, (size_t)xn);

    if (lazy) mark_needed(y, yn, need);
    else      for (k = 0; k < 10; k++) need[k] = (k >= 2);

    for (k = 2; k <= 9; k++) {
        if (!need[k]) continue;
        memcpy(t[k], t[CHAIN[k][0]], (size_t)tn);
        add_at(t[k], tn, t[CHAIN[k][1]], tn, 0);
    }

    memset(out, 0, (size_t)(xn + yn));
    for (j = 0; j < yn; j++) {
        uint8_t d = y[j];
        if (d == 0) continue;               /* nothing to add */
        add_at(out, xn + yn, t[d], tn, j);  /* j IS the shift */
    }
}

/* Preferred entry point: picks the cheaper ordering, then multiplies. */
void dec_mul_auto(const uint8_t *x, int xn,
                  const uint8_t *y, int yn,
                  uint8_t *out)
{
    if (prefer_swap(x, xn, y, yn)) dec_mul(y, yn, x, xn, out, 1);
    else                           dec_mul(x, xn, y, yn, out, 1);
}

/* ---- test harness ---------------------------------------------------- */

static int to_digits(uint64_t v, uint8_t *d)
{
    int n = 0;
    if (v == 0) { d[0] = 0; return 1; }
    while (v) { d[n++] = (uint8_t)(v % 10); v /= 10; }
    return n;
}

static uint64_t from_digits(const uint8_t *d, int n)
{
    uint64_t v = 0;
    while (n--) v = v * 10 + d[n];
    return v;
}

int main(void)
{
    uint8_t x[MAXD], y[MAXD], out[MAXD];
    uint64_t cases[][2] = {
        {726, 25}, {0, 999}, {999, 0}, {1, 1}, {9, 9},
        {99999, 99999}, {123456, 987654}, {1000001, 999999},
        {7, 8}, {50, 20}, {305, 407}
    };
    int i, fail = 0;

    for (i = 0; i < (int)(sizeof cases / sizeof cases[0]); i++) {
        uint64_t a = cases[i][0], b = cases[i][1];
        int xn = to_digits(a, x), yn = to_digits(b, y);
        uint64_t got, want = a * b, adds_full, adds_lazy;

        g_digit_adds = 0;
        dec_mul(x, xn, y, yn, out, 0);
        adds_full = g_digit_adds;
        got = from_digits(out, xn + yn);

        g_digit_adds = 0;
        dec_mul(x, xn, y, yn, out, 1);
        adds_lazy = g_digit_adds;

        printf("%10llu x %-8llu = %-16llu %s   adds: full %3llu  lazy %3llu\n",
               (unsigned long long)a, (unsigned long long)b,
               (unsigned long long)got,
               got == want ? "ok " : "FAIL",
               (unsigned long long)adds_full, (unsigned long long)adds_lazy);
        if (got != want) fail = 1;
        if (from_digits(out, xn + yn) != want) fail = 1;
    }

    /* exhaustive sweep, both orderings and the auto entry point */
    for (uint64_t a = 0; a < 400; a++)
        for (uint64_t b = 0; b < 400; b++) {
            int xn = to_digits(a, x), yn = to_digits(b, y);
            dec_mul(x, xn, y, yn, out, 1);
            if (from_digits(out, xn + yn) != a * b) fail = 1;
            dec_mul_auto(x, xn, y, yn, out);
            if (from_digits(out, xn + yn) != a * b) fail = 1;
            if (fail) {
                printf("SWEEP FAIL %llu x %llu\n",
                       (unsigned long long)a, (unsigned long long)b);
                goto done;
            }
        }

    /* ordering: does the predictor actually pick the cheaper side? */
    {
        uint64_t base = 0, best = 0, chosen = 0;
        int wrong = 0, checked = 0;

        for (uint64_t a = 2; a < 3000; a += 7)
            for (uint64_t b = 2; b < 3000; b += 11) {
                int xn = to_digits(a, x), yn = to_digits(b, y);
                uint64_t cf, cr, cc;

                g_digit_adds = 0; dec_mul(x, xn, y, yn, out, 1); cf = g_digit_adds;
                g_digit_adds = 0; dec_mul(y, yn, x, xn, out, 1); cr = g_digit_adds;
                g_digit_adds = 0; dec_mul_auto(x, xn, y, yn, out); cc = g_digit_adds;

                base += cf;
                best += (cf < cr ? cf : cr);
                chosen += cc;
                if (cf != cr) { checked++; if (cc != (cf < cr ? cf : cr)) wrong++; }
            }

        printf("\nordering over %d decided pairs\n", checked);
        printf("  predictor picked the cheaper side : %d / %d\n",
               checked - wrong, checked);
        printf("  total adds, given order           : %llu\n",
               (unsigned long long)base);
        printf("  total adds, auto order            : %llu  (%.1f%% saved)\n",
               (unsigned long long)chosen,
               100.0 * (double)(base - chosen) / (double)base);
        if (chosen != best || wrong) fail = 1;
    }

done:
    printf("\n%s\n", fail ? "FAILURES PRESENT" : "all tests passed");
    return fail;
}
