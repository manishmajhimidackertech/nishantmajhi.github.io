# Verification bundle

Everything needed to check the numbers in *Recursion in Multiplication*.

Run everything at once:

    make check

Or run the three pieces separately:

    cc -O2 -std=c99 decmul.c -o decmul && ./decmul
    node ordering.js
    node radix.js

You need a C compiler and Node.js. Nothing else, and no libraries.
Both scripts are deterministic: `radix.js` uses a fixed random seed, so it
prints the same numbers on every machine.

## Which file checks which claim

| Claim in the paper | Where | Checked by |
|---|---|---|
| The algorithm is correct | Section 5 | `decmul` and `ordering.js` both sweep every product from 0×0 to 399×399 |
| The multiples table costs nine additions | Section 3 | `decmul.c`, the `CHAIN` array |
| No shift operation is ever performed | Section 4 | `decmul.c`, the `j` argument to `add_at` |
| 726 × 25 costs 20 additions | Section 7 | `./decmul`, first line |
| Radix 10 is the worst choice on binary storage | Section 1 | `node radix.js`, first table |
| A precomputed ×10 still loses | Section 4 | `node radix.js`, second table |
| Reversing the operands helps 43.9% of the time | Section 7 | `node ordering.js` |
| The ordering predictor is never wrong | Section 7 | `node ordering.js`, 104,642 pairs |
| Choosing the better order saves 12.3% | Section 7 | `node ordering.js` |

## Files

- `decmul.c` — the reference implementation, plus its own test harness
- `ordering.js` — operand ordering measurements and a correctness sweep
- `radix.js` — the radix comparison behind the argument for decimal storage
- `Makefile` — runs all three

## Notes

`decmul.c` and `ordering.js` implement the same algorithm independently, one in
C and one in JavaScript. They agree on every product and on every addition
count, which is the point of writing it twice.

The interactive demo inside the HTML page is a third implementation of the same
algorithm. If all three agree, the algorithm is probably right.

## Licence

Public domain. Use it however you like.
