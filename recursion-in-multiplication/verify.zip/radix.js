/* radix.js — reproduces the radix comparison in Section 1 and the scaled-table
 * figures in Section 4. Run with:  node radix.js
 *
 * Cost model: a binary-word machine with an adder and no shifter, so the only
 * way to double is x + x. One addition of two words counts as one operation,
 * whatever the width.
 */
"use strict";

const CHAIN = [[0,0],[0,0],[1,1],[1,2],[2,2],[1,4],[3,3],[1,6],[4,4],[3,6]];

/* Fixed-seed generator so every run of this file prints the same numbers. */
function mulberry32(a){
  return function(){
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/* Additions needed to build a set of multiples from {1}, halving each target. */
function buildCost(targets){
  const req = new Set(), stack = [...targets].filter(d => d > 1);
  while (stack.length){
    const k = stack.pop();
    if (req.has(k)) continue;
    req.add(k);
    const a = Math.floor(k/2), b = k - a;
    for (const v of [a,b]) if (v > 1 && !req.has(v)) stack.push(v);
  }
  return req.size;
}

/* Additions needed using the paper's decimal chain (Section 3). */
function chainCost(targets){
  const req = new Set(), stack = [...targets].filter(d => d > 1);
  while (stack.length){
    const k = stack.pop();
    if (req.has(k)) continue;
    req.add(k);
    for (const v of CHAIN[k]) if (v > 1 && !req.has(v)) stack.push(v);
  }
  return req.size;
}

function toDigits(v, radix){
  const d = [];
  while (v > 0){ d.push(v % radix); v = Math.floor(v / radix); }
  return d.length ? d : [0];
}

/* Horner from most significant digit down: acc = acc*radix + table[digit] */
function costRadix2k(y, k){
  const dig = toDigits(y, 2 ** k);
  let ops = buildCost(new Set(dig));
  for (let j = dig.length - 1; j >= 0; j--){
    if (j < dig.length - 1) ops += k;      /* k doublings of the accumulator */
    if (dig[j] !== 0) ops += 1;            /* add the selected multiple */
  }
  return ops;
}

function costRadix10(y){
  const dig = toDigits(y, 10);
  let ops = chainCost(new Set(dig));
  for (let j = dig.length - 1; j >= 0; j--){
    if (j < dig.length - 1) ops += 4;      /* x10 needs the chain 1,2,4,8,10 */
    if (dig[j] !== 0) ops += 1;
  }
  return ops;
}

/* Section 4: keep the whole multiples table scaled, advancing one decimal
 * place per step via T'[1] = T[5] + T[5]. This is the only formulation in
 * which a precomputed x10 entry is actually used. */
function costScaledTable(y){
  const dig = toDigits(y, 10);
  let ops = 0;
  for (let j = 0; j < dig.length; j++){
    const wanted = new Set();
    if (dig[j] > 1) wanted.add(dig[j]);
    if (j + 1 < dig.length) wanted.add(5);   /* 5 is needed to advance */
    ops += chainCost(wanted);                /* rebuild from the scaled T[1] */
    if (dig[j] !== 0) ops += 1;              /* accumulate */
    if (j + 1 < dig.length) ops += 1;        /* T'[1] = T[5] + T[5] */
  }
  return ops;
}

const N = 4000, rand = mulberry32(20260807), ys = [];
for (let i = 0; i < N; i++) ys.push(Math.floor(rand() * 2 ** 31) + 1);
const mean = f => (ys.reduce((s, y) => s + f(y), 0) / N).toFixed(1);

console.log("Section 1 — radix comparison on a binary word machine");
console.log("32-bit operands, add-only, no shifter, mean additions\n");
console.log("  radix   table entries   mean adds");
for (const k of [1,2,3,4]){
  console.log("  " + String(2 ** k).padEnd(8) +
              String(2 ** k - 2).padStart(9) +
              String(mean(y => costRadix2k(y, k))).padStart(12));
}
console.log("  " + "10".padEnd(8) + "8".padStart(9) +
            String(mean(costRadix10)).padStart(12));

console.log("\nSection 4 — can a precomputed x10 replace decimal storage?\n");
console.log("  scaled multiples table, uses t[10] = t[5] + t[5] :", mean(costScaledTable));
console.log("  Horner with a fresh x10 chain each position      :", mean(costRadix10));
console.log("  radix 4, two-entry table                         :", mean(y => costRadix2k(y, 2)));
